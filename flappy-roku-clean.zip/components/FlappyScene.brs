sub init()
    m.top.backgroundColor = "0x70C5CEFF"
    m.top.SetFocus(true)

    m.scoreLabel = m.top.FindNode("scoreLabel")
    m.messageLabel = m.top.FindNode("messageLabel")
    m.hintLabel = m.top.FindNode("hintLabel")
    m.timer = m.top.FindNode("gameTimer")
    m.timer.ObserveField("fire", "onTick")

    m.worldWidth = 1280
    m.worldHeight = 720
    m.groundY = 628
    m.birdX = 278
    m.birdSize = 46
    m.gravity = 0.68
    m.flapPower = -11.4
    m.pipeWidth = 86
    m.pipeGap = 204
    m.pipeSpacing = 364
    m.pipeSpeed = 4.2
    m.pipeStartX = 1360
    m.frame = 0

    createWorld()
    resetGame()
end sub

sub createWorld()
    m.clouds = []
    for i = 0 to 4
        cloud = CreateObject("roSGNode", "Rectangle")
        cloud.width = 120 + (i mod 2) * 38
        cloud.height = 28 + (i mod 3) * 8
        cloud.color = "0xCFF3F4AA"
        cloud.translation = [95 + i * 278, 82 + (i mod 3) * 56]
        m.top.AppendChild(cloud)
        m.clouds.Push(cloud)
    end for

    m.pipes = []
    for i = 0 to 2
        pair = {
            top: CreateObject("roSGNode", "Rectangle"),
            bottom: CreateObject("roSGNode", "Rectangle"),
            capTop: CreateObject("roSGNode", "Rectangle"),
            capBottom: CreateObject("roSGNode", "Rectangle"),
            x: 0,
            gapY: 0,
            scored: false
        }
        pair.top.width = m.pipeWidth
        pair.top.color = "0x39A844FF"
        pair.bottom.width = m.pipeWidth
        pair.bottom.color = "0x39A844FF"
        pair.capTop.width = m.pipeWidth + 26
        pair.capTop.height = 30
        pair.capTop.color = "0x2F8F38FF"
        pair.capBottom.width = m.pipeWidth + 26
        pair.capBottom.height = 30
        pair.capBottom.color = "0x2F8F38FF"

        m.top.AppendChild(pair.top)
        m.top.AppendChild(pair.bottom)
        m.top.AppendChild(pair.capTop)
        m.top.AppendChild(pair.capBottom)
        m.pipes.Push(pair)
    end for

    m.ground = CreateObject("roSGNode", "Rectangle")
    m.ground.translation = [0, m.groundY]
    m.ground.width = m.worldWidth
    m.ground.height = m.worldHeight - m.groundY
    m.ground.color = "0xDDBB70FF"
    m.top.AppendChild(m.ground)

    m.grass = CreateObject("roSGNode", "Rectangle")
    m.grass.translation = [0, m.groundY]
    m.grass.width = m.worldWidth
    m.grass.height = 18
    m.grass.color = "0x7BC84DFF"
    m.top.AppendChild(m.grass)

    m.bird = CreateObject("roSGNode", "Rectangle")
    m.bird.width = m.birdSize
    m.bird.height = m.birdSize
    m.bird.color = "0xFFD74AFF"
    m.top.AppendChild(m.bird)

    m.birdEye = CreateObject("roSGNode", "Rectangle")
    m.birdEye.width = 8
    m.birdEye.height = 8
    m.birdEye.color = "0x202020FF"
    m.top.AppendChild(m.birdEye)

    m.birdBeak = CreateObject("roSGNode", "Rectangle")
    m.birdBeak.width = 18
    m.birdBeak.height = 12
    m.birdBeak.color = "0xFF8C2BFF"
    m.top.AppendChild(m.birdBeak)
end sub

sub resetGame()
    m.state = "ready"
    m.score = 0
    m.velocity = 0
    m.birdY = 302
    m.frame = 0

    for i = 0 to m.pipes.Count() - 1
        pipe = m.pipes[i]
        pipe.x = m.pipeStartX + i * m.pipeSpacing
        pipe.gapY = getGapY(i)
        pipe.scored = false
        positionPipe(pipe)
    end for

    updateBird()
    updateHud()
    m.timer.control = "start"
end sub

function getGapY(seed as dynamic) as integer
    pattern = [246, 318, 212, 374, 286, 342, 232]
    index = (m.score + Int(seed) + m.frame) mod pattern.Count()
    return pattern[index]
end function

sub updateHud()
    m.scoreLabel.text = m.score.ToStr()

    if m.state = "ready" then
        m.messageLabel.text = "FLAPPY ROKU"
        m.hintLabel.text = "Press OK or UP to flap"
    else if m.state = "gameover" then
        m.messageLabel.text = "GAME OVER"
        m.hintLabel.text = "Press OK to play again"
    else
        m.messageLabel.text = ""
        m.hintLabel.text = ""
    end if
end sub

sub onTick()
    m.frame = m.frame + 1
    moveClouds()

    if m.state <> "playing" then return

    m.velocity = m.velocity + m.gravity
    m.birdY = m.birdY + m.velocity

    for each pipe in m.pipes
        pipe.x = pipe.x - m.pipeSpeed
        if pipe.x < -m.pipeWidth - 30 then
            pipe.x = getRightmostPipeX() + m.pipeSpacing
            pipe.gapY = getGapY(pipe.x)
            pipe.scored = false
        end if

        if pipe.scored = false and pipe.x + m.pipeWidth < m.birdX then
            pipe.scored = true
            m.score = m.score + 1
            updateHud()
        end if

        positionPipe(pipe)
    end for

    updateBird()

    if hitSomething() then
        m.state = "gameover"
        m.velocity = 0
        updateHud()
    end if
end sub

sub moveClouds()
    for each cloud in m.clouds
        x = cloud.translation[0] - 0.45
        if x < -180 then x = m.worldWidth + 40
        cloud.translation = [x, cloud.translation[1]]
    end for
end sub

function getRightmostPipeX() as float
    rightmost = 0
    for each pipe in m.pipes
        if pipe.x > rightmost then rightmost = pipe.x
    end for
    return rightmost
end function

sub positionPipe(pipe as object)
    topHeight = pipe.gapY - (m.pipeGap / 2)
    bottomY = pipe.gapY + (m.pipeGap / 2)
    bottomHeight = m.groundY - bottomY

    pipe.top.height = topHeight
    pipe.top.translation = [pipe.x, 0]

    pipe.bottom.height = bottomHeight
    pipe.bottom.translation = [pipe.x, bottomY]

    pipe.capTop.translation = [pipe.x - 13, topHeight - 30]
    pipe.capBottom.translation = [pipe.x - 13, bottomY]
end sub

sub updateBird()
    m.bird.translation = [m.birdX, m.birdY]
    m.birdEye.translation = [m.birdX + 30, m.birdY + 12]
    m.birdBeak.translation = [m.birdX + 40, m.birdY + 23]
end sub

function hitSomething() as boolean
    if m.birdY < 0 then return true
    if m.birdY + m.birdSize > m.groundY then return true

    birdLeft = m.birdX
    birdRight = m.birdX + m.birdSize
    birdTop = m.birdY
    birdBottom = m.birdY + m.birdSize

    for each pipe in m.pipes
        pipeLeft = pipe.x
        pipeRight = pipe.x + m.pipeWidth

        if birdRight > pipeLeft and birdLeft < pipeRight then
            gapTop = pipe.gapY - (m.pipeGap / 2)
            gapBottom = pipe.gapY + (m.pipeGap / 2)
            if birdTop < gapTop or birdBottom > gapBottom then return true
        end if
    end for

    return false
end function

function onKeyEvent(key as string, press as boolean) as boolean
    if press = false then return false

    if key = "OK" or key = "up" then
        if m.state = "gameover" then
            resetGame()
        else
            m.state = "playing"
            m.velocity = m.flapPower
            updateHud()
        end if
        return true
    else if key = "back" then
        return false
    end if

    return true
end function
